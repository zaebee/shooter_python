## Meta info:

	Credit: Aleksander Kowalczyk, Retrocade.net
	Source game: Galagian
	Licensed under: Creative Commons Attribution 4.0 International (https://creativecommons.org/licenses/by/4.0/)
	
	Play the game: http://retrocade.net/game/galagian/ 
	Source code: https://github.com/RetrocadeNet/galagian
	Support Retrocade.net: http://retrocade.net/how-to-support-retrocade-net/

	More opensource games and artwork on: 
	http://retrocade.net/open-art/
	
## Notes:

	The actual game used the font Goca Logotype Beta, by Jonas Borneland Hansen and is available here: http://www.dafont.com/goca-logotype-beta.font
	
	/unused contains graphics which were not used direclty in the game. Some of them are achievements icons from Newgrounds.
	
	/src contains source files (PSDs can be opened in Adobe Photoshop or with limited support in Gimp).